# webbscrapers_api
Python module to access Webbscrapers API - https://webbscrapers.live

Created for easy access to Webbscrapers API - an API that allows for easy access to World Health Organisation reports - parsed and scanned by symptoms, location, diseases, etc.

Created for UNSW's SENG3011 course.
